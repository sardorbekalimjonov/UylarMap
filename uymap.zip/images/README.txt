Rasmlarni shu papkaga qo'ying (masalan p1.jpg), keyin script.js ning boshidagi RASMLAR ro'yxatiga yozing:
  p1: ["images/p1.jpg"],
